package lista_encadeada;

public interface Iterador {
	
	public boolean temProximo();
	
	public int obterProximoElemento();
}
